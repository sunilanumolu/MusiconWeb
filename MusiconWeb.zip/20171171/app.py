from flask import Flask,render_template, redirect, url_for, flash, session, request, logging
from flask_mysqldb import MySQL
from wtforms import Form, StringField, TextAreaField, PasswordField, validators
from passlib.hash import sha256_crypt
from functools import wraps
from musicdownloader import download
import glob, os

# init Flask App
app = Flask(__name__)


# ----------------------- Config MySQL ------------------------>
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'hello'
app.config['MYSQL_DB'] = 'mymusicapp'
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'
# ------------------------------------------------------------->


# init MySQL
mysql = MySQL(app)


# ---------------------------- Home --------------------------->
@app.route("/", methods=['GET', 'POST'])
def welcome():
	return render_template("home.html")
# ------------------------------------------------------------->
                

# --------------------- RegisterForm Class -------------------->
class RegisterForm(Form):
    name = StringField('Name', [validators.Length(min=1, max=50)])
    username = StringField('Username', [validators.Length(min=4, max=25)])
    email = StringField('Email', [validators.Length(min=6, max=50)])
    password = PasswordField('Password', [
        validators.DataRequired(),
        validators.EqualTo('confirm', message='Passwords do not match')
    ])
    confirm = PasswordField('Confirm Password')
# ------------------------------------------------------------->


# -------------------------- Register ------------------------->
@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm(request.form)
    if request.method == 'POST' and form.validate():

        # Get entered user info from form
        name = form.name.data
        email = form.email.data
        username = form.username.data
        password = sha256_crypt.encrypt(str(form.password.data))

        # Create cursor
        cur = mysql.connection.cursor()

        # Check if username already exists
        x = cur.execute("SELECT * FROM users WHERE username = %s", [username])

        if not x:

            # Execute query
            cur.execute("INSERT INTO users(name, email, username, password) VALUES(%s, %s, %s, %s)", (name, email, username, password))

            # Commit to DB
            mysql.connection.commit()

            # Close connection
            cur.close()

            flash('You aur now registered and can login.', 'success')

            return redirect(url_for('login'))
        
        else:

            # If username is taken
            flash('That username is already taken.', 'danger')

    return render_template('register.html', form=form)
# ------------------------------------------------------------>


# -------------------------- Login --------------------------->
@app.route('/login', methods=['GET', 'POST'])
def login():

    error_username = None
    error_password = None

    if request.method == 'POST':
        # Get form fields
        username = request.form['username']
        password_candidate = request.form['password']

        # Create cursor
        cur = mysql.connection.cursor()

        # Get user by username
        result = cur.execute("SELECT * FROM users WHERE username = %s", [username])

        if result:

            # Get stored hash
            data = cur.fetchone()
            password = data['password']

            # Compare passwords
            if sha256_crypt.verify(password_candidate, password):
                # Passed
                session['logged_in'] = True
                session['username'] = username

                # flash('You are now logged in', 'success')

                return redirect(url_for('profile', username=username))
            else:
                error_password = 'Invalid credentials'
                return render_template('login.html', error_username=error_username, error_password=error_password)
            
            # Close connection
            cur.close()

        else:
            error_username = 'Username not found'
            return render_template('login.html', error_username=error_username, error_password=error_password)
        
    return render_template('login.html', error_username=error_username, error_password=error_password)
# ------------------------------------------------------------>


# ---------------- Login Required Decorator ------------------>
def login_required(f):
    @wraps(f)
    def wrap(*args, **kwargs):
        if 'logged_in' in session:
            return f(*args, **kwargs)
        else:
            flash("You need to login first", 'danger')
            return redirect(url_for('login'))
    return wrap
# ------------------------------------------------------------>


# -------------------------- Logout -------------------------->
@app.route('/logout', methods=['GET', 'POST'])
@login_required
def logout():
    session.clear()
    flash("You have been logged out", 'success')
    return redirect(url_for('welcome'))
# ------------------------------------------------------------>


# ----------------------- List Of Users ---------------------->
@app.route('/users', methods=['GET', 'POST'])
def users():

    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM users')
    users_list = cur.fetchall()
    cur.close()

    return render_template('users.html', users_list=users_list)
# ------------------------------------------------------------>


# ----------------- User Public Playlists Page --------------->
@app.route('/users/<int:user_id>/', methods=['GET', 'POST'])
def User(user_id):
    
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM users WHERE id = %s', [user_id])
    data = cur.fetchone()
    # cur.execute("SELECT * FROM userplaylists WHERE id = %s AND playlisttype = 'Public'", [user_id])
    # public_playlists = cur.fetchall()
    cur.execute('SELECT public FROM users WHERE id = %s', [user_id])
    public_data = cur.fetchone()

    public_playlists = []
    if public_data['public'] is not None:
        playlist_ids = public_data['public'].split(',')
        for p_id in playlist_ids:
            cur.execute('SELECT name FROM playlists WHERE id = %s', [p_id])
            p_name = cur.fetchone()
            public_playlists.append({'id': p_id, 'name': p_name['name']})

    cur.close()

    return render_template("user.html", data=data, public_playlists=public_playlists)
# ------------------------------------------------------------>


# ----------------------- User Profile ----------------------->
@app.route('/profile/<string:username>', methods=['GET', 'POST'])
@login_required
def profile(username):

    # Stop user from accessing other users' profiles
    if username != session['username']:
        flash("You need to login as " + username + " to access their private profile.", 'danger')
        return redirect(url_for('profile', username=session['username']))

    # If user is creating a playlist
    if request.method == 'POST':

        if 'del_id' not in request.form:

            name = request.form['name']
            p_type = request.form['ptype']

            cur = mysql.connection.cursor()
            cur.execute('SELECT * FROM users WHERE username = %s', [username])
            user_data = cur.fetchone()
            
            cur.execute('INSERT INTO playlists(name) VALUES(%s)', [name])
            cur.execute('SELECT id FROM playlists WHERE name = %s', [name])
            new_id = cur.fetchone()
            
            old_list = []
            if user_data[p_type] is not None:
                old_list = user_data[p_type].split(',')
            old_list.append(str(new_id['id']))
            new_list = ','.join(old_list)

            if p_type == 'public':
                cur.execute('UPDATE users SET public = %s WHERE id = %s', (new_list, user_data['id']))
            else:
                cur.execute('UPDATE users SET private = %s WHERE id = %s', (new_list, user_data['id']))

            mysql.connection.commit()
            cur.close()

            flash('Playlist made successfully', 'success')
            return redirect(url_for('profile', username=username))

        else:

            del_id = request.form['del_id']
            del_type = request.form['del_type']

            cur = mysql.connection.cursor()
            cur.execute("SELECT name FROM playlists WHERE id = %s", [del_id])
            p_name = cur.fetchone()['name']
            cur.execute("DELETE FROM playlists WHERE id = %s", [del_id])
            p_ids = None
            if del_type == 'public':
                cur.execute("SELECT public FROM users WHERE username = %s", [username])
                p_ids = cur.fetchone()['public'].split(',')
            else:
                cur.execute("SELECT private FROM users WHERE username = %s", [username])
                p_ids = cur.fetchone()['private'].split(',')
            p_ids.remove(del_id)
            p_string = ','.join(p_ids)
            if p_string:
                if del_type == 'public':
                    cur.execute("UPDATE users SET public = %s WHERE username = %s", (p_string, username))
                else:
                    cur.execute("UPDATE users SET private = %s WHERE username = %s", (p_string, username))
            else:
                if del_type == 'public':
                    cur.execute("UPDATE users SET public = NULL WHERE username = %s", [username])
                else:
                    cur.execute("UPDATE users SET private = NULL WHERE username = %s", [username])
            mysql.connection.commit()
            cur.close()

            flash("The playlist " + str(p_name) + " was deleted successfully", 'success')
            return redirect(url_for('profile', username=username))
            

    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM users WHERE username = %s', [username])
    user_data = cur.fetchone()

    public_playlists = []
    private_playlists = []

    if user_data['public'] is not None:
        public_ids = user_data['public'].split(',')
        for p_id in public_ids:
            cur.execute('SELECT name FROM playlists WHERE id = %s', [p_id])
            p_data = cur.fetchone()
            public_playlists.append({'id': p_id, 'name': p_data['name']})

    if user_data['private'] is not None:
        private_ids = user_data['private'].split(',')
        for p_id in private_ids:
            cur.execute('SELECT name FROM playlists WHERE id = %s', [p_id])
            p_data = cur.fetchone()
            private_playlists.append({'id': p_id, 'name': p_data['name']})

    cur.close()

    return render_template('profile.html', user_data=user_data, public_playlists=public_playlists, private_playlists=private_playlists)
# ------------------------------------------------------------>

# ---------------------- Search Results ---------------------->
@app.route('/search', methods=['GET', 'POST'])
def search():
    
    song_name = request.form['song']
    if song_name:

        search_words = song_name.split(' ')
        
        search_term = '%'
        for word in search_words:
            search_term += word + '%'
        cur = mysql.connection.cursor()
        cur.execute("SELECT id, name, img_name, singer FROM songs WHERE name LIKE '{}'".format(search_term))
        song_data = cur.fetchall()

        if not song_data:

            is_downloaded = download(song_name)
            if is_downloaded:

                song_data = {}
                for file in glob.glob("*.mp3"):
                    audio_name = str(file)
                    name = audio_name.split('.mp3')[0]
                    singer = 'Artist Not Available'
                    song_string = name.split(' - ')
                    if len(song_string) > 1:
                        singer = song_string[0]
                os.system("mv *.mp3 ./static/Music/")

                for file in glob.glob("*.jpg"):
                    img_name = str(file)
                os.system("mv *.jpg ./static/musicImg")

                cur.execute("INSERT INTO songs(name, singer, audio_name, img_name) VALUES(%s, %s, %s, %s)", (name, singer, audio_name, img_name))

                mysql.connection.commit()


        cur.execute("SELECT id, name, img_name, singer FROM songs WHERE name LIKE '{}'".format(search_term))
        song_data = cur.fetchall()
        cur.close()

    else:

        song_data = {}

    return render_template('search.html', song_data=song_data, query=song_name)
# ------------------------------------------------------------>


# ------------------------- All Songs ------------------------>
@app.route("/songs", methods=['GET', 'POST'])
def songs():

    if request.method == 'POST':

        playlist_id = request.form['id']
        song_id = request.form['songid']

        cur = mysql.connection.cursor()
        cur.execute("SELECT songs FROM playlists WHERE id = %s", [playlist_id])

        songs_string = cur.fetchone()['songs']
        songs_list = []
        if songs_string:
            songs_list = songs_string.split(',')

        if song_id in songs_list:
            flash("Song already in playlist", 'danger')
            return redirect(url_for('songs'))
        
        songs_list.append(song_id)
        songs = ','.join(songs_list)

        cur.execute("UPDATE playlists SET songs = %s WHERE id = %s", (songs, playlist_id))
        mysql.connection.commit()
        cur.close()

        flash("Song added successfully.", 'success')
        return redirect(url_for('songs'))


    # Fetch all songs from songs table and store into songs_list
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM songs")
    songs_list = cur.fetchall()

    public_playlists = []
    private_playlists = []

    if 'logged_in' in session:

        cur.execute("SELECT public, private FROM users WHERE username = %s", [session['username']])
        playlists = cur.fetchone()

        public_playlists_ids = []
        private_playlists_ids = []

        if playlists['public'] is not None:
            public_playlists_ids = playlists['public'].split(',')
        if playlists['private'] is not None:
            private_playlists_ids = playlists['private'].split(',')

        for x in public_playlists_ids:
            cur.execute("SELECT name FROM playlists WHERE id = %s", [x])
            public_playlists.append({'id': x, 'type': 'public', 'name': cur.fetchone()['name']})
        for x in private_playlists_ids:
            cur.execute("SELECT name FROM playlists WHERE id = %s", [x])
            private_playlists.append({'id': x, 'type': 'private', 'name': cur.fetchone()['name']})

    cur.close()

    return render_template("songs.html", songs=songs_list, public_playlists=public_playlists, private_playlists=private_playlists)
# ------------------------------------------------------------>


# --------------------------- Player ------------------------->
@app.route("/song/<int:song_id>/", methods=['GET', 'POST'])
def song(song_id):

    if request.method == 'POST':

        playlist_id = request.form['id']
        song_id = request.form['songid']

        cur = mysql.connection.cursor()
        cur.execute("SELECT songs FROM playlists WHERE id = %s", [playlist_id])

        songs_string = cur.fetchone()['songs']
        songs_list = []
        if songs_string:
            songs_list = songs_string.split(',')

        if song_id in songs_list:
            flash("Song already in playlist", 'danger')
            return redirect(url_for('song', song_id=song_id))
        
        songs_list.append(song_id)
        songs = ','.join(songs_list)

        cur.execute("UPDATE playlists SET songs = %s WHERE id = %s", (songs, playlist_id))
        mysql.connection.commit()
        cur.close()

        flash("Song added successfully.", 'success')
        return redirect(url_for('songs'))
	
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM songs WHERE id = %s", [song_id])
    data = cur.fetchone()
    cur.execute("SELECT * FROM songs")
    songs_list = cur.fetchall()


    public_playlists = []
    private_playlists = []

    if 'logged_in' in session:

        cur.execute("SELECT public, private FROM users WHERE username = %s", [session['username']])
        playlists = cur.fetchone()

        public_playlists_ids = []
        private_playlists_ids = []

        if playlists['public'] is not None:
            public_playlists_ids = playlists['public'].split(',')
        if playlists['private'] is not None:
            private_playlists_ids = playlists['private'].split(',')

        for x in public_playlists_ids:
            cur.execute("SELECT name FROM playlists WHERE id = %s", [x])
            public_playlists.append({'id': x, 'type': 'public', 'name': cur.fetchone()['name']})
        for x in private_playlists_ids:
            cur.execute("SELECT name FROM playlists WHERE id = %s", [x])
            private_playlists.append({'id': x, 'type': 'private', 'name': cur.fetchone()['name']})


    cur.close()

    return render_template("song.html", data=data, songs_list=songs_list, private_playlists=private_playlists, public_playlists=public_playlists)
# ------------------------------------------------------------>


# --------------------- Playlist View ------------------------>
@app.route('/user/<int:user_id>/<int:p_id>/<string:p_type>')
@app.route('/user/<int:user_id>/<int:p_id>/<string:p_type>/<int:song_id>')
def playlist(user_id, p_id, p_type, song_id=None):

    cur = mysql.connection.cursor()
    if p_type == 'private':
        cur.execute("SELECT username FROM users WHERE id = %s", [user_id])

        username = cur.fetchone()['username']
        if username != session['username']:
            cur.close()
            flash("You need to login as %s to view their private playlists".format(username), 'danger')
            return redirect(url_for('login'))

    songs_list_ids = []
    cur.execute("SELECT songs, name FROM playlists WHERE id = %s", [p_id])
    p_data = cur.fetchone()
    p_name = p_data['name']
    songs_string = p_data['songs']
    if songs_string:
        songs_list_ids = songs_string.split(',')

    songs_list = []
    if songs_list_ids:
        for x in songs_list_ids:
            cur.execute("SELECT * FROM songs WHERE id = %s", [x])
            songs_list.append(cur.fetchone())
    
    data = {}
    if song_id is not None:
        cur.execute("SELECT * FROM songs WHERE id = %s", [song_id])
        data = cur.fetchone()
    
    cur.close()

    return render_template('playlist.html', data=data, songs_list=songs_list, user_id=user_id, p_id=p_id, p_type=p_type, p_name=p_name)
# ----------------------------------------------------------->
        
        
if __name__ == "__main__":
	app.secret_key = '1\xceg\xe1\xde\x96A$d6\x8e\xf0*\x07\xe6\xbezM\x9f}\xc2\x97P\xba'
	app.run(debug=True, threaded=True)