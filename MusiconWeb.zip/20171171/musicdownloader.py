import os
import requests
from bs4 import BeautifulSoup

def download(song):
    # Scraping YouTube for the song link
    try:
        page = requests.get("https://www.youtube.com/results?search_query="+song)
        soup = BeautifulSoup(page.text,'html.parser')
        
        for div in soup.find_all('div', { "class" : "yt-lockup-video" }):
            if div.get("data-context-item-id") != None:
                video_id = div.get("data-context-item-id")
                break

        # Using Youtube-dl by https://github.com/rg3/youtube-dl/ for download and ffmpeg for conversion.
        os.system('youtube-dl -x --audio-format mp3 --audio-quality 0 --output "%(title)s.%(ext)s" https://www.youtube.com/watch?v='+video_id)
        os.system("youtube-dl "+"--write-thumbnail "+"--skip-download "+ " https://www.youtube.com/watch?v="+video_id)

        return True

    except NameError:
        return False