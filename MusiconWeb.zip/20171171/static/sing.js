var $btn = $(".btn");
var audio= $(".audio").get(0);

$btn.on('click',function(){
	if(audio.paused){
		audio.play();
	}else{
		audio.pause();
	}
});

