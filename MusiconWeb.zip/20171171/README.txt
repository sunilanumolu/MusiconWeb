// Need mysql-server and libmysqlclient-dev packages for mysql command line
// Set password as 'hello' when asked to add password

// Start mysql service on terminal
> service mysql start

// Go to mysql command line
> mysql -u root -p
Enter password: hello

// Now queries for mysql command line

// Create and use database mymusicapp
CREATE DATABASE mymusicapp;
USE mymusicapp;

// Create the tables necessary for app

// table 'users'
CREATE TABLE users(id INT(11) PRIMARY KEY AUTO_INCREMENT, name VARCHAR(100), email VARCHAR(100), username VARCHAR(30), password VARCHAR(100), register_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP, public VARCHAR(2000), private VARCHAR(2000));
// to add users just register

// table 'songs'
CREATE TABLE songs(id INT(11), name VARCHAR(200), singer VARCHAR(100), img_name VARCHAR(210), audio_name VARCHAR(210), create_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
// to add rows just search on search bar provided in app

// table 'playlists'
CREATE TABLE playlists(id INT(11) PRIMARY KEY AUTO_INCREMENT, name VARCHAR(200), songs VARCHAR(2000));
// make playlists on user profile page to add rows
